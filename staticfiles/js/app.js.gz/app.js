$(document).ready(function() {

  $(".owl-demo").owlCarousel({
    items : 3,
    lazyLoad : true,
    navigation : true
  });

});

